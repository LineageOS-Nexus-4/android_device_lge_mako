#!/sbin/sh
#
# Mako restore to stock layout: 21 system 840MB, 22 cache 560MB, 23 userdata = rest
# DDR (24) / grow (25) untouched. New metadata (26) removed, "mdata" renamed back
# to "metadata". Tools run from /tmp (LD_LIBRARY_PATH). Full log: /tmp/install.log
# NOTE: install this zip from /tmp, NOT from /sdcard (TWRP holds /data open
# while reading the zip and parted refuses to touch mounted partitions).

set -o pipefail 2>/dev/null || true

export LD_LIBRARY_PATH=/tmp
export MKE2FS_CONFIG=/tmp/mke2fs.conf
PARTED=/tmp/parted
MKE2FS=/tmp/mke2fs
LOG=/tmp/install.log

if type ui_print >/dev/null 2>&1; then :; else ui_print() { echo "ui_print $*"; }; fi
if type stdout_to_ui_print >/dev/null 2>&1; then STREAM=stdout_to_ui_print; else STREAM=cat; fi
say() { echo "$@" | tee -a $LOG | $STREAM; }

echo "=== mako restore-to-stock $(date) ===" > $LOG

say "Reading current partition table...";
$PARTED /dev/block/mmcblk0 unit b p quit 2>&1 | tee -a $LOG > /tmp/part
[ -s /tmp/part ] || { say "ERROR: parted failed to read partition table"; exit 1; }

if ! grep -q "mdata" /tmp/part; then
  say "Not in resized state (no mdata found). Nothing to restore.";
  exit 1;
fi

if grep -q "7817134079B" /tmp/part; then
  DEV=8g
  UI="Nexus 4 8GB"
  UDATA_END=7817134079B
  UDATA_SIZE=6189744128B
else
  DEV=16g
  UI="Nexus 4 16GB"
  UDATA_END=15756951551B
  UDATA_SIZE=14129561600B
fi
say "Detected: $UI";

say "Unmounting partitions...";
umount /system 2>&1 | tee -a $LOG | $STREAM || true
umount /vendor 2>&1 | tee -a $LOG | $STREAM || true
umount /data 2>&1 | tee -a $LOG | $STREAM || true
umount /sdcard 2>&1 | tee -a $LOG | $STREAM || true
umount /cache 2>&1 | tee -a $LOG | $STREAM || true
umount -l /data 2>&1 | tee -a $LOG | $STREAM || true
umount -l /sdcard 2>&1 | tee -a $LOG | $STREAM || true
sync

if mount | grep -qE "mmcblk0p2[1-6]"; then
  say "Some partitions still mounted (TWRP may hold them). Retrying lazy unmount...";
  sleep 2
  umount -l /data 2>&1 | tee -a $LOG | $STREAM || true
  umount -l /sdcard 2>&1 | tee -a $LOG | $STREAM || true
  sync
fi
if mount | grep -qE "mmcblk0p2[1-6]"; then
  say "ERROR: a partition is still mounted. Wait for TWRP to settle and retry the install.";
  say "Log: $LOG";
  exit 1;
fi

say "Building parted command script...";
{
  for p in 21 22 23 26; do
    grep -q "^ *$p " /tmp/part && echo "rm $p"
  done
  echo "name 18 metadata"
  echo "mkpart primary 159383552B 1040187391B"
  echo "name 21 system"
  echo "mkpart primary 1040187392B 1627389951B"
  echo "name 22 cache"
  echo "mkpart primary 1627389952B $UDATA_END"
  echo "name 23 userdata"
  echo "quit"
} > /tmp/cmds
cat /tmp/cmds | tee -a $LOG | $STREAM

say "Restoring stock partition table...";
$PARTED /dev/block/mmcblk0 < /tmp/cmds 2>&1 | tee -a $LOG | $STREAM
sync
sleep 2

say "Verifying layout...";
$PARTED /dev/block/mmcblk0 unit b p quit 2>&1 | tee -a $LOG > /tmp/part
grep -q "$UDATA_SIZE" /tmp/part || {
  say "ERROR: layout verification failed (expected userdata size $UDATA_SIZE).";
  say "Log: $LOG";
  exit 1;
}

say "Waiting for partition devices...";
for i in 1 2 3 4 5 6 7 8 9 10; do
  [ -e /dev/block/mmcblk0p21 ] && [ -e /dev/block/mmcblk0p22 ] && [ -e /dev/block/mmcblk0p23 ] && break
  sleep 1
done
[ -e /dev/block/mmcblk0p23 ] || { say "ERROR: partition devices did not appear. Log: $LOG"; exit 1; }

say "Formatting system/cache/userdata as ext4...";
$MKE2FS -t ext4 -m 0 /dev/block/mmcblk0p21 2>&1 | tee -a $LOG | $STREAM || { say "ERROR: formatting p21 (system) failed. Log: $LOG"; exit 1; }
$MKE2FS -t ext4 -m 0 /dev/block/mmcblk0p22 2>&1 | tee -a $LOG | $STREAM || { say "ERROR: formatting p22 (cache) failed. Log: $LOG"; exit 1; }
$MKE2FS -t ext4 -m 0 /dev/block/mmcblk0p23 2>&1 | tee -a $LOG | $STREAM || { say "ERROR: formatting p23 (userdata) failed. Log: $LOG"; exit 1; }
sync

rm -f /tmp/parted /tmp/mke2fs /tmp/libext2fs.so /tmp/libext2_blkid.so /tmp/libext2_uuid.so /tmp/libext2_profile.so /tmp/libext2_quota.so /tmp/libext2_com_err.so /tmp/libext2_e2p.so /tmp/mke2fs.conf /tmp/revert.sh /tmp/cmds /tmp/part

say "Restore done. Rebooting into recovery...";
reboot recovery
